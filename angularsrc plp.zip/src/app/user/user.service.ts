import { Injectable } from '@angular/core';
import { User } from '../model/user.interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userUrl = 'http://localhost:5050';
  user: User;
  constructor(private http: HttpClient) { }
  getAllUsers() {
    return this.http.get<User[]>(this.userUrl);
  }
  createUser(user: User): Observable<User[]> {
    return this.http.post<User[]>(this.userUrl + "/add", user);
  }
  deleteUser(user: User) {
    return this.http.delete<User[]>(this.userUrl + "/delete/" + user.id);
  }
  editUser(user: User) {
    return this.http.put(this.userUrl + "/edit/" + user.id, user);
  }
  getUser(id: number) {
    return this.http.get<User>(this.userUrl + "/users/" + id);
  }
}
