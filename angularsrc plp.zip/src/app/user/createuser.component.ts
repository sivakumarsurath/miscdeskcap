import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.interface';
import { UserService } from './user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {

  userData:User={"id":0,"email":'',"fullname":'',"password":''};
  constructor(private userService:UserService,
    private router:Router) { }

  ngOnInit() {
  }
createUser(){
  this.userService.createUser(this.userData).subscribe(data=>{this.router.navigate([''])});
}

}
