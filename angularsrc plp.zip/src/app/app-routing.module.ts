import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserlistComponent } from './user/userlist.component';
import { CreateuserComponent } from './user/createuser.component';
import { EdituserComponent } from './user/edituser.component';


const routes: Routes = [
  {path:'',component : UserlistComponent},
  {path:'create',component : CreateuserComponent},
  {path:'edit/:id',component : EdituserComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
