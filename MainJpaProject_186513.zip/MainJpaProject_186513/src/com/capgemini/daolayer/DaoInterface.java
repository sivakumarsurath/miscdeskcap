package com.capgemini.daolayer;

import java.util.List;

import com.capgemini.Exceptionlayer.AccountException;
import com.capgemini.beanlayer.Account;
import com.capgemini.beanlayer.Customer;
import com.capgemini.beanlayer.Transaction;

public interface DaoInterface {
	int getCustomerId()throws AccountException;
	long generateAccountNo()throws AccountException;
	boolean addAccount(Account account) throws AccountException;
	Account ValidateLogin(String name, int pass) throws AccountException;
	double getBalance(String name, int pass) throws AccountException;
	boolean withdraw(double amt, String name, int pass) throws AccountException;
	boolean deposit(double amt, String name, int pass) throws AccountException;
	boolean addCustomer(Customer customer) throws AccountException;
	int generateId() throws AccountException;
	boolean addtransaction(Transaction transaction) throws AccountException;
	List<Transaction> getTrans(String name, int pass) throws AccountException;
	

}
