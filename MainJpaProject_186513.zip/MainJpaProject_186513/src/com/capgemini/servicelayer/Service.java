package com.capgemini.servicelayer;

import java.util.List;

import com.capgemini.Exceptionlayer.AccountException;
import com.capgemini.beanlayer.Account;
import com.capgemini.beanlayer.Customer;
import com.capgemini.beanlayer.Transaction;

public interface Service {


	boolean ValidateName(String Name) throws AccountException ;

	boolean validateEmail(String Email) throws AccountException;

	boolean validatePhoneNumber(String phone) throws AccountException;

	boolean validateAmount(double ammount) throws AccountException;
	int getCustomerId()throws AccountException;
	long generateAccountNo()throws AccountException;

	boolean addAccount(Account account) throws AccountException;

	Account ValidateLogin(String name, int pass) throws AccountException;

	double getBalance(String name, int pass) throws AccountException;

	boolean validateWithdraw(double amt) throws AccountException;

	boolean withdraw(double amt, String name, int pass) throws AccountException;

	boolean deposit(double amt, String name, int pass) throws AccountException;

	boolean addCustomer(Customer customer) throws AccountException;

	int dtransacId() throws AccountException;

	boolean addTransaction(Transaction transaction) throws AccountException;

	List<Transaction> getTransaction(String name, int pass) throws AccountException;

}
