package com.cg.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.dto.User;

@RestController
public class GreetController {
	
	@RequestMapping("/greet")
	public String sayHello() {
		return "Hello";
	}
	@RequestMapping("/user")
	public User getUser() {
		return new User(500,"Mark",23,"Bangalore");
	}

}
