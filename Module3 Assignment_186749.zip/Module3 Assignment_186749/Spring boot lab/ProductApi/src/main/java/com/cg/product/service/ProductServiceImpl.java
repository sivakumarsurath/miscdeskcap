package com.cg.product.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

/***
 * 
 * @author ssurath DATE of creation :21-08-2019
 */

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productDao;

	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		/*
		 * productDao.save(product); return productDao.findAll();
		 */
		try {

			if (product.getQuantity() <1) {
				throw new ProductException("Quantity should be more than 1");
			}
			if (product.getCategory().equals("Mobile") || product.getCategory().equals("TV")
					|| product.getCategory().equals("Laptop")) {
				productDao.save(product);

				return getAllProducts();
			} else {
				throw new ProductException("Category should be either Mobile,TV or Laptop");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> updateProduct(int id, Product product) throws ProductException {
		if (productDao.existsById(id)) {
			Product prod = productDao.findById(id).get();
			prod.setPrice(product.getPrice());
			prod.setQuantity(product.getQuantity());
			productDao.save(prod);
			return getAllProducts();
		} else {
			throw new ProductException("Invalid Product, cannot be  updated");
		}
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {

		try {
			return productDao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> productByCategory(String catName) throws ProductException {
		return productDao.productByCategory(catName);

	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
if(productDao.existsById(id)) {
			
	productDao.deleteById(id);
			return getAllProducts();
		}else {
			throw new ProductException("cannot delete. Employee with Id "+id+" does not exist");
		}
	}

}
