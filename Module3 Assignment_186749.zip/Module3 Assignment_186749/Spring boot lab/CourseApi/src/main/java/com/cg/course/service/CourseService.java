package com.cg.course.service;

import java.util.List;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;

public interface CourseService {
	
	List<Course> addCourse(Course course) throws CourseException;

	List<Course> getAllCourses() throws CourseException;

	List<Course> updateCourse(String id, Course course) throws CourseException;

	List<Course> deleteCourse(String id)throws CourseException;

	Course getCourseById(String id)throws CourseException;

	List<Course> getCourseByMode(String mode)throws CourseException;

}
