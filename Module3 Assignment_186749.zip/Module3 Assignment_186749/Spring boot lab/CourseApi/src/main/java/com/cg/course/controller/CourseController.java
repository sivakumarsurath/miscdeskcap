package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;

@RestController
@RequestMapping("/api")
public class CourseController {

	@Autowired
	private CourseService courseService;
	@PostMapping("/courses")
	public List<Course> addCourse(@RequestBody Course course) throws CourseException{
		return courseService.addCourse(course);
		
	}
	@GetMapping("/courses")
	public List<Course> getAllCourses() throws CourseException{
		return courseService.getAllCourses();
		
	}
	@PutMapping("/courses/{id}")
	public List<Course> updateCourse(@RequestBody Course course,@PathVariable String id) throws CourseException{
		return courseService.updateCourse(id,course);
	}
	@DeleteMapping("/courses/{id}")
	public List<Course> deleteCourse(@PathVariable String id) throws CourseException{
		return courseService.deleteCourse(id);
	}
	@GetMapping("/courses/{id}")
	public Course getCourseById(@PathVariable String id) throws CourseException {
		return courseService.getCourseById(id);
	}
	@GetMapping("/courses/mode")
	public List<Course> getCourseByMode(@RequestParam String mode) throws CourseException{
		return courseService.getCourseByMode(mode);
	}
	
}
