package com.cg.emp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.emp.exception.EmployeeException;

@ControllerAdvice
public class ExceptionController {
	@ExceptionHandler(EmployeeException.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
		
	}

}
