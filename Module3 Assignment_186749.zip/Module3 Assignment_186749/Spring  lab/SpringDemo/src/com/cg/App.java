package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class App {
	public static void main(String[] args) {

		/*
		 * BeanFactory factory= new XmlBeanFactory(new
		 * FileSystemResource("spring.xml"));
		 */
		/*
		 * ApplicationContext context = new
		 * ClassPathXmlApplicationContext("spring.xml");
		 */

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		context.registerShutdownHook();
		/*
		 * Triangle triangle = context.getBean("triangle", Triangle.class);
		 * triangle.draw();
		 */
		/*
		 * Circle cir=(Circle) context.getBean("circle"); cir.draw();
		 */

		Employee e = (Employee) context.getBean("employee");
		System.out.println(e.getDob());
	}

}
