package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Circle implements BeanNameAware, BeanFactoryAware, InitializingBean, DisposableBean{
	private Point center;

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}
	public void draw() {
		System.out.println("Circle Drawn");
		System.out.println("Circle Points ("+center.getX()+","+center.getY()+")");
	}

	@Override
	public void setBeanName(String beanName) {
		System.out.println("Bean Name= "+beanName);
	
		
	}

	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("Set BeanFactory Method called by the container");
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("After properties set of initializing bean");
		
	}

	public void  startUp(){
		System.out.println("My Init Method");
		
	}

	@Override
	public void destroy() throws Exception {
	System.out.println("Destroy Method of disposal bean");
		
	}
}
